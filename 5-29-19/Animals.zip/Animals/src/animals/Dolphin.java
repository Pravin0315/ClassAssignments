package animals;

public class Dolphin {
}
